"use client"
import CommentForm from "@/components/comment-form"

export default function Home() {
  return (
    <main className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-2xl mx-auto">
          <header className="mb-8">
            <h1 className="text-4xl font-bold text-foreground mb-2">Questions & Answers</h1>
            <p className="text-muted-foreground">Share your feedback on Q&A content with AI-powered suggestions</p>
          </header>

          {/* Sample Q&A Section */}
          <div className="bg-card border border-border rounded-lg p-6 mb-8">
            <div className="mb-6">
              <h2 className="text-2xl font-semibold text-foreground mb-2">How to optimize database queries?</h2>
              <p className="text-muted-foreground mb-4">Asked by John • 2 hours ago</p>
              <p className="text-card-foreground">
                I have a large dataset and my queries are running slow. What are the best practices for optimizing
                database performance? Should I use indexes, query caching, or maybe consider a different database
                architecture?
              </p>
            </div>

            <div className="bg-background rounded p-4 mb-6">
              <h3 className="font-semibold text-foreground mb-3">Answer by Jane • 1 hour ago</h3>
              <p className="text-card-foreground">
                Great question! Here are the key optimization strategies: 1) Add proper indexes on frequently queried
                columns, 2) Use query analysis to identify bottlenecks, 3) Implement caching for repeated queries, 4)
                Consider denormalization for read-heavy workloads.
              </p>
            </div>

            {/* Comment Form Component */}
            <CommentForm question="How to optimize database queries?" />
          </div>
        </div>
      </div>
    </main>
  )
}
