export async function POST(req: Request) {
  try {
    const { question, comment, likeResponse, usedAISuggestion } = await req.json()

    console.log("Comment submitted:", {
      question,
      comment,
      likeResponse,
      usedAISuggestion,
      timestamp: new Date().toISOString(),
    })

    // TODO: Save to your database/backend
    // Example:
    // await db.comments.create({
    //   question,
    //   comment,
    //   likeResponse,
    //   usedAISuggestion,
    //   createdAt: new Date(),
    // });

    return Response.json({
      success: true,
      message: "Comment submitted successfully",
    })
  } catch (error) {
    console.error("Error submitting comment:", error)
    return Response.json({ error: "Failed to submit comment" }, { status: 500 })
  }
}
