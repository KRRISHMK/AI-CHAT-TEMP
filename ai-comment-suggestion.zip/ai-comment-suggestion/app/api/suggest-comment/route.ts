import { generateText } from "ai"

export async function POST(req: Request) {
  try {
    const { question } = await req.json()

    const { text } = await generateText({
      model: "openai/gpt-4o-mini",
      prompt: `You are a helpful community moderator reviewing Q&A content. Generate 3 different constructive comments that could improve this Q&A. Each comment should offer a different perspective (e.g., clarity improvement, additional context, alternative approach).

Question: "${question}"

Format your response as a JSON array with exactly 3 objects like this:
[
  { "title": "Short title", "comment": "The actual comment text here" },
  { "title": "Short title", "comment": "The actual comment text here" },
  { "title": "Short title", "comment": "The actual comment text here" }
]

Only return valid JSON, nothing else.`,
      maxTokens: 300,
      temperature: 0.7,
    })

    const suggestions = JSON.parse(text.trim())

    return Response.json({
      suggestions: Array.isArray(suggestions) ? suggestions : [{ title: "Feedback", comment: text.trim() }],
    })
  } catch (error) {
    console.error("[v0] Error generating suggestion:", error)
    return Response.json(
      {
        suggestions: [
          {
            title: "Default Feedback",
            comment: "Consider providing more context or examples in your response for clarity.",
          },
        ],
      },
      { status: 200 },
    )
  }
}
