"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Loader2, CheckCircle2, XCircle, ChevronLeft, ChevronRight, Sparkles, RotateCcw } from "lucide-react"

interface CommentFormProps {
  question: string
}

interface Suggestion {
  title: string
  comment: string
}

export default function CommentForm({ question }: CommentFormProps) {
  const [likeResponse, setLikeResponse] = useState<"yes" | "no" | null>(null)
  const [suggestions, setSuggestions] = useState<Suggestion[]>([])
  const [currentSuggestionIndex, setCurrentSuggestionIndex] = useState(0)
  const [comment, setComment] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [showSuggestions, setShowSuggestions] = useState(false)
  const [submitted, setSubmitted] = useState(false)

  const handleLikeResponse = async (response: "yes" | "no") => {
    setLikeResponse(response)
    setSubmitted(false)
    setComment("")
    setShowSuggestions(false)
    setSuggestions([])
    setCurrentSuggestionIndex(0)

    if (response === "no") {
      await generateSuggestions()
    }
  }

  const generateSuggestions = async () => {
    setIsLoading(true)
    try {
      const response = await fetch("/api/suggest-comment", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ question }),
      })

      if (!response.ok) throw new Error("Failed to generate suggestions")

      const data = await response.json()
      setSuggestions(data.suggestions || [])
      setCurrentSuggestionIndex(0)
      setShowSuggestions(true)
    } catch (error) {
      console.error("Error generating suggestions:", error)
      setSuggestions([{ title: "Feedback", comment: "Could not generate suggestions. Please type your own feedback." }])
      setShowSuggestions(true)
    } finally {
      setIsLoading(false)
    }
  }

  const nextSuggestion = () => {
    setCurrentSuggestionIndex((prev) => (prev + 1) % suggestions.length)
  }

  const prevSuggestion = () => {
    setCurrentSuggestionIndex((prev) => (prev - 1 + suggestions.length) % suggestions.length)
  }

  const acceptSuggestion = () => {
    setComment(suggestions[currentSuggestionIndex].comment)
    setShowSuggestions(false)
  }

  const rejectSuggestion = () => {
    setComment("")
    setSuggestions([])
    setShowSuggestions(false)
  }

  const regenerateSuggestions = async () => {
    setSuggestions([])
    setShowSuggestions(false)
    setComment("")
    await generateSuggestions()
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!comment.trim()) return

    setIsSubmitting(true)
    try {
      const response = await fetch("/api/submit-comment", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          question,
          comment,
          likeResponse,
          usedAISuggestion: showSuggestions === false && suggestions.length > 0,
        }),
      })

      if (response.ok) {
        setSubmitted(true)
        setComment("")
        setLikeResponse(null)
        setSuggestions([])
        setTimeout(() => setSubmitted(false), 3000)
      }
    } catch (error) {
      console.error("Error submitting comment:", error)
    } finally {
      setIsSubmitting(false)
    }
  }

  const currentSuggestion = suggestions[currentSuggestionIndex]

  return (
    <div className="space-y-4">
      {/* Radio Button Section */}
      <div className="bg-background rounded-lg p-4 border border-border">
        <p className="font-semibold text-foreground mb-3">Did you find this Q&A helpful with comments?</p>
        <div className="flex gap-6">
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="radio"
              name="like-response"
              value="yes"
              checked={likeResponse === "yes"}
              onChange={() => handleLikeResponse("yes")}
              className="w-4 h-4"
            />
            <span className="text-card-foreground">Yes, it was helpful</span>
          </label>
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="radio"
              name="like-response"
              value="no"
              checked={likeResponse === "no"}
              onChange={() => handleLikeResponse("no")}
              className="w-4 h-4"
            />
            <span className="text-card-foreground">No, I have suggestions</span>
          </label>
        </div>
      </div>

      {/* Comment Section - Only show if user selected a response */}
      {likeResponse && (
        <div className="bg-background rounded-lg p-4 border border-border animate-in fade-in slide-in-from-top-2 duration-300">
          <p className="font-semibold text-foreground mb-3">
            {likeResponse === "yes" ? "Leave a comment" : "Share your feedback"}
          </p>

          {/* AI Suggestions Carousel */}
          {showSuggestions && suggestions.length > 0 && currentSuggestion && (
            <div className="mb-4 p-4 bg-gradient-to-br from-purple-50 to-blue-50 dark:from-purple-950 dark:to-blue-950 border border-purple-200 dark:border-purple-800 rounded-lg animate-in fade-in duration-300">
              <div className="flex items-center gap-2 mb-3">
                <Sparkles className="w-5 h-5 text-purple-600 dark:text-purple-400" />
                <p className="text-sm font-semibold text-purple-900 dark:text-purple-200">
                  AI Suggestion {currentSuggestionIndex + 1} of {suggestions.length}
                </p>
              </div>

              {/* Suggestion Title Badge */}
              <div className="mb-3">
                <span className="inline-block px-3 py-1 text-xs font-semibold text-white bg-purple-600 dark:bg-purple-500 rounded-full">
                  {currentSuggestion.title}
                </span>
              </div>

              {/* Suggestion Content */}
              <p className="text-sm text-gray-700 dark:text-gray-300 mb-4 p-3 bg-white dark:bg-slate-900 rounded-lg leading-relaxed">
                {currentSuggestion.comment}
              </p>

              {/* Navigation & Action Buttons */}
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={prevSuggestion}
                  disabled={suggestions.length <= 1}
                  className="p-2 text-purple-600 dark:text-purple-400 hover:bg-purple-100 dark:hover:bg-purple-900 disabled:opacity-50 disabled:cursor-not-allowed rounded transition-colors"
                  aria-label="Previous suggestion"
                >
                  <ChevronLeft className="w-5 h-5" />
                </button>

                <div className="flex gap-1">
                  {suggestions.map((_, idx) => (
                    <button
                      key={idx}
                      onClick={() => setCurrentSuggestionIndex(idx)}
                      className={`h-2 rounded-full transition-all duration-300 ${
                        idx === currentSuggestionIndex
                          ? "bg-purple-600 dark:bg-purple-400 w-6"
                          : "bg-purple-200 dark:bg-purple-700 w-2 hover:bg-purple-300"
                      }`}
                      aria-label={`Go to suggestion ${idx + 1}`}
                    />
                  ))}
                </div>

                <button
                  type="button"
                  onClick={nextSuggestion}
                  disabled={suggestions.length <= 1}
                  className="p-2 text-purple-600 dark:text-purple-400 hover:bg-purple-100 dark:hover:bg-purple-900 disabled:opacity-50 disabled:cursor-not-allowed rounded transition-colors"
                  aria-label="Next suggestion"
                >
                  <ChevronRight className="w-5 h-5" />
                </button>

                <div className="flex-1" />

                <button
                  type="button"
                  onClick={regenerateSuggestions}
                  disabled={isLoading}
                  className="flex items-center gap-1 text-sm px-4 py-2 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed text-white rounded-lg transition-colors font-medium"
                  title="Generate different suggestions"
                >
                  <RotateCcw className={`w-4 h-4 ${isLoading ? "animate-spin" : ""}`} />
                  Regenerate
                </button>

                <button
                  type="button"
                  onClick={acceptSuggestion}
                  className="flex items-center gap-1 text-sm px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg transition-colors font-medium"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  Accept
                </button>
                <button
                  type="button"
                  onClick={rejectSuggestion}
                  className="flex items-center gap-1 text-sm px-4 py-2 bg-gray-300 dark:bg-gray-600 hover:bg-gray-400 dark:hover:bg-gray-700 text-gray-900 dark:text-gray-100 rounded-lg transition-colors font-medium"
                >
                  <XCircle className="w-4 h-4" />
                  Reject
                </button>
              </div>
            </div>
          )}

          {/* Loading State */}
          {isLoading && (
            <div className="mb-4 p-4 bg-gradient-to-r from-blue-50 to-cyan-50 dark:from-blue-950 dark:to-cyan-950 border border-blue-200 dark:border-blue-800 rounded-lg animate-in fade-in duration-300">
              <div className="flex items-center gap-3">
                <Loader2 className="w-5 h-5 animate-spin text-blue-600 dark:text-blue-400" />
                <div className="flex-1">
                  <p className="text-sm font-medium text-blue-900 dark:text-blue-200">Generating AI suggestions...</p>
                  <p className="text-xs text-blue-700 dark:text-blue-300 mt-1">This usually takes a few seconds</p>
                </div>
              </div>
            </div>
          )}

          {/* Comment Input */}
          <form onSubmit={handleSubmit} className="space-y-3">
            <Textarea
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              placeholder={
                likeResponse === "no" ? "Accept a suggestion or type your own feedback..." : "Share your thoughts..."
              }
              className="min-h-24 bg-white dark:bg-slate-900 text-foreground border-border focus:ring-2 focus:ring-primary resize-none"
              disabled={isLoading}
            />

            <div className="flex gap-2">
              <Button
                type="submit"
                disabled={!comment.trim() || isSubmitting}
                className="bg-primary hover:bg-primary/90 text-primary-foreground font-medium"
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Submitting...
                  </>
                ) : (
                  "Submit Comment"
                )}
              </Button>

              {likeResponse === "no" && !showSuggestions && suggestions.length > 0 && (
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setShowSuggestions(true)}
                  disabled={isLoading}
                  className="border-border hover:bg-accent"
                >
                  View Suggestions ({suggestions.length})
                </Button>
              )}
            </div>
          </form>

          {/* Success Message */}
          {submitted && (
            <div className="mt-4 p-3 bg-gradient-to-r from-green-50 to-emerald-50 dark:from-green-950 dark:to-emerald-950 border border-green-200 dark:border-green-800 rounded-lg flex items-center gap-2 animate-in fade-in duration-300">
              <CheckCircle2 className="w-4 h-4 text-green-600 dark:text-green-400" />
              <p className="text-sm text-green-700 dark:text-green-300 font-medium">Comment submitted successfully!</p>
            </div>
          )}
        </div>
      )}
    </div>
  )
}
