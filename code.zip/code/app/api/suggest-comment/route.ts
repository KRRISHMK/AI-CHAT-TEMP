const FALLBACK_SUGGESTIONS = [
  {
    title: "Clarity Improvement",
    comment: "Could you provide more specific examples to clarify this point? It would help readers understand better.",
  },
  {
    title: "Additional Context",
    comment: "This answer would be even more helpful if you included information about why this approach works.",
  },
  {
    title: "Alternative Perspective",
    comment: "Have you considered mentioning alternative approaches? It would give readers a more complete picture.",
  },
  {
    title: "Real-world Example",
    comment: "Adding a real-world example or use case would make this more practical and easier to implement.",
  },
  {
    title: "Performance Note",
    comment: "It might be worth mentioning the performance implications or best practices for this approach.",
  },
]

export async function POST(req: Request) {
  try {
    const { question } = await req.json()

    if (!question || typeof question !== "string") {
      return Response.json({ suggestions: FALLBACK_SUGGESTIONS.slice(0, 3) }, { status: 200 })
    }

    try {
      const { generateText } = await import("ai")

      const { text } = await generateText({
        model: "openai/gpt-4o-mini",
        prompt: `You are a helpful community moderator. Generate 3 different constructive feedback comments for this Q&A question. Each should have a unique perspective.

Question: "${question}"

Return ONLY valid JSON array with exactly 3 objects in this format:
[
  { "title": "Short Title", "comment": "The constructive feedback" },
  { "title": "Short Title", "comment": "The constructive feedback" },
  { "title": "Short Title", "comment": "The constructive feedback" }
]`,
        maxTokens: 400,
        temperature: 0.7,
      })

      const suggestions = JSON.parse(text.trim())

      if (Array.isArray(suggestions) && suggestions.length >= 3) {
        return Response.json({ suggestions })
      }
    } catch (aiError) {
      console.log("[v0] AI generation skipped, using fallback suggestions")
    }

    const shuffled = [...FALLBACK_SUGGESTIONS].sort(() => Math.random() - 0.5)

    return Response.json({
      suggestions: shuffled.slice(0, 3),
    })
  } catch (error) {
    console.error("[v0] Error in suggest-comment:", error)
    return Response.json({
      suggestions: FALLBACK_SUGGESTIONS.slice(0, 3),
    })
  }
}
